<?php
/* Template Name: coming-soon */
?>

<?php get_header(); ?>

<!-- Your HTML content here -->
<canvas id="dotGrid"></canvas>
   <div class="container">
	
	   
	   <div class="circle">
		   <?php echo ugoki_hero_animation(array(
         'variant' => 'ani',
         'class'   => '',
         'width'   => 200,
         'height'  => 200,
         'alt'     => 'Ugoki UI animation',
       )); ?>
	   </div>

    <div class="title">
      <img src="/wp-content/uploads/2026/05/logo.svg" alt="<?php bloginfo('name'); ?>" width="200" height="60" decoding="async">
    </div>

    <div class="subtitle title-small">
      Ugoki UI is a Figma motion library for simple animations and micro-interactions that helps designers work up to 4× faster.
    </div>
    <br>
    <br>
    <br>
    <div class="subtitle title-x-small" style="text-transform: uppercase; letter-spacing: 2px;">
       / a <a href="https://www.instagram.com/creotopi/" target="_blank" style="color: #111; text-decoration: none;">creotopi</a> product \
    </div>


  </div>

<?php get_footer(); ?>